package com.azhar.tpk.network.model

data class Geometry(

        var location: Location?

)