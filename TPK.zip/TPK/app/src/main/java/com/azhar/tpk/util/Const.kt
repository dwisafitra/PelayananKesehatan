package com.azhar.tpk.util

class Const {

    companion object {
        var lat: Double? = null
        var lng: Double? = null
    }

}