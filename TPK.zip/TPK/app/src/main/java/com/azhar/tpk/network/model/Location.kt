package com.azhar.tpk.network.model

data class Location(

        var lat: String?,
        var lng: String?

)